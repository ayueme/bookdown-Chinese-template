# 随机分组 {#randomsss}



随机分组在临床设计中太常见了，只要你搞临床研究，必定会遇到随机分组的问题。

随机分组临床比较常用的也就是4种：
- 简单随机simple randomization
- 区组随机blocked randomization
- 分层随机stratified randomization
- 整群随机cluster randomization
- ......

## 简单随机

比如30个人，按照完全随机化的方法分为2组，一组试验组，一组对照组，每组15人。

## 区组随机

可以用`randomizr`实现区组随机：

还可以顺便帮我们生成PDF文件，方便装入信封。
