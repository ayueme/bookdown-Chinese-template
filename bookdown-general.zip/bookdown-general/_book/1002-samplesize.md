# 样本量计算 {#xlnfgl}



样本量计算也是医学统计学中的一块重要内容，但是在课本中并没有详细介绍，今天我们说一下常见的研究设计的样本量计算。

通常样本量计算大家可能知道PASS软件，这是一个专门用来计算样本量的软件，但是也是付费的，并且没有mac版，而R语言免费，谁都可以用，不过！计算样本量我还是推荐使用PASS，因为简单好用！除了PASS外，大家还可以用gpower计算样本量哦~

## t检验的样本量计算

对于t检验，可以使用`pwr.t.test(n= , d= , sig.level= , power= , type= , alternative= )`计算样本量，其中。。。。。。。

### 单样本t检验（样本均数和已知总体均数比较）

使用课本例36-3的例子。

用某药治疗矽肺患者，估计可增加尿矽排出量，其标准差为25mg/L，若要求以α=0.05，β=0.1的概率，能辨别出尿矽排出量平均增加10mg/L，问需要多少矽肺患者做实验？


```r
library(pwr)
## Warning: package 'pwr' was built under R version 4.2.3

pwr.t.test(d = 10/25, 
           sig.level = 0.05,
           power = 1-0.1,
           type = "one.sample",
           alternative = "greater"
           )
## 
##      One-sample t test power calculation 
## 
##               n = 54.90553
##               d = 0.4
##       sig.level = 0.05
##           power = 0.9
##     alternative = greater
```

