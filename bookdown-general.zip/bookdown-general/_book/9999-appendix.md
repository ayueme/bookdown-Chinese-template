# (PART) 附录 {-}

# (APPENDIX) 附录 {#appendix .unnumbered}

# R语言和R包安装 



## R语言、Rtools、Rstudio的安装 
请参考公众号推文：可能是最适合小白的R语言和R包安装教程
链接： https://mp.weixin.qq.com/s/T_THmO1J94mj88pwHoqi2Q
或者b站视频：https://www.bilibili.com/video/BV1jY411w7zq?share_source=copy_web

## R包安装 
请参考公众号推文：可能是最好的R包安装教程
链接： https://mp.weixin.qq.com/s/7kW8wlDyRRTahy8XtCeX1w
或者b站视频：https://www.bilibili.com/video/BV11g411o7be?share_source=copy_web

## PASS软件链接 
关注公众号：医学和生信笔记，后台回复 PASS 即可获得软件链接。

