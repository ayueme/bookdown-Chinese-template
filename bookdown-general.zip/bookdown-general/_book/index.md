--- 
title: "这是你的标题"
author: "阿越就是我"
date: "2023-09-12"
documentclass: ctexbook
#bibliography: [book.bib, packages.bib]
#biblio-style: apalike
colorlinks: yes
link-citations: yes
site: bookdown::bookdown_site
description: "随便写点什么"
github-repo: xxx/xxx
url: "https://xxx.com/"
---

# 前言 {-}

## 本书缘起 {-}

R语言是一门编程语言，但同时也是一个统计软件，R语言是由统计学家开发的，所以天生就适合做统计。

由于R和SPSS在进行统计分析时的一些数学计算方面并不是完全一致，所以导致有些结果和课本中的结果有些出入，但是并不影响结果的正确性。

限于本人水平等问题，难免会有一些错误，欢迎大家以各种方式批评指正，比如公众号留言、粉丝QQ群、github、个人微信等。

本书会不定期更新，内容和格式都会不断完善。

*更新日志*：

- 20230905：
  - 格式升级，改为3列式；
  - RCS增加推荐阅读；
  - 。。。

> 注意：本书实际上是我公众号历史推文的汇总，**书中涉及的所有数据都可以在相关历史推文中免费获取！**历史推文合集链接：[医学统计学](https://mp.weixin.qq.com/mp/appmsgalbum?__biz=MzUzOTQzNzU0NA==&action=getalbum&album_id=2231476971388059661&scene=126#wechat_redirect)
>
> 我也准备了一个PDF版合集，内容和网页版一致，只是打包了所有的数据，付费获取（10元），介意勿扰！**PDF版合集获取链接**：[常见医学统计方法R语言实现合集](https://mp.weixin.qq.com/s/IG-TaO9Vg_YS6o9fKYw5jw)

## 作者简介 {-}

这是一段测试这是一段测试这是一段测试这是一段测试这是一段测试。

这是一段测试这是一段测试这是一段测试这是一段测试。












